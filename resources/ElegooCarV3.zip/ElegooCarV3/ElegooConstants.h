#ifndef __ELEGOO_CONSTANTS_H__
#define __ELEGOO_CONSTANTS_H__

class ElegooConstants
{
public:
	static const int OK = 0;
};

#endif
